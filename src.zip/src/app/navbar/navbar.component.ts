import { Component, HostListener,Renderer2, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  activeSection: string = 'welcome'; // Set the initial active section
  folders: any[] = [
    { name: 'portfolio', files: ['File 1', 'File 2'], expanded: true },
    // Add more folders as needed
  ];
  tabs = [{name:'home', title:'home.html'}];
  setActiveSection(sectionId: string) {
    this.activeSection = sectionId;
  }
  isExplorerOpen: boolean = true;

  toggleExplorer() {
      this.isExplorerOpen = !this.isExplorerOpen;
  }
  toggleDropdown(folder: any): void {
    folder.expanded = !folder.expanded;
  }

  constructor(private renderer: Renderer2) { }

  ngOnInit(): void {
  }




}
